function varargout = Number_Plate_Reader(varargin)
clc;
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @Number_Plate_Reader_OpeningFcn, ...
                   'gui_OutputFcn',  @Number_Plate_Reader_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);

if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end


if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
function Number_Plate_Reader_OpeningFcn(hObject, eventdata, handles, varargin)
handles.output = hObject;
guidata(hObject, handles);

initialize_gui(hObject, handles, false);
function varargout = Number_Plate_Reader_OutputFcn(hObject, eventdata, handles)
varargout{1} = handles.output;
function initialize_gui(fig_handle, handles, isreset)
if isfield(handles, 'metricdata') && ~isreset
    return;
end
guidata(handles.figure1, handles);
function[text1]= pushbutton10_Callback(hObject, eventdata, handles)
    [baseFileName,folder]=uigetfile('*.*','samples','carplate2.jpg');
    fullimageFileName=fullfile(folder,baseFileName);
    axes1=imread(fullimageFileName);
    axes(handles.axes1);

    image(axes1)
    %prompt={'Enter the number of charcters to read:'};
    %dlg_title = 'Number of Characters';
    %num_lines = 1;
    %def = {'0'};
    %answer = inputdlg(prompt,dlg_title,num_lines,def);
    %no = str2num(answer{1});
    
    text1 = myExtractor(fullimageFileName);
    fid = fopen('kjnumberplate.txt','wt');
    fprintf(fid,text1);
    fclose(fid);
%--------------------------------------------------------------------------    


found = false;
fid = fopen('database.txt','r');
while(feof(fid) == 0)
    tline = fgetl(fid);
    if ischar(tline) && ~isempty(strfind(tline, text1))
        found = true;
        break;
    end
end


fclose(fid);
  % fid = fopen('datbase.txt','r');
   %line  = str2int(0);
   %found = false;

   
  %while ~feof(fid)
   % tline = fgetl(fid);
    %line = line + 1;
    %if ischar(tline) && ~isempty(strfind(tline, text1))
     %   found = true;
      %  break;
    %end
%end
%fclose(fid);

text2 = 'USER NOT FOUND IN THE DATABASE VEHICLE IS NOT ALLOWED TO PASS';
text3 = 'USER FOUND IN THE DATABASE VEHICLE IS ALLOWED TO PASS';

if found
    msgbox(text3,'Output');end
if ~found
    msgbox(text2,'Output');end

   msgbox(text1,'Output');
 
